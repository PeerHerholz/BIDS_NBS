# -*- coding: utf-8 -*-
"""
BIDS to BIDS-NBS example
=====================================
This example demonstrates how to use :mod:``bidnbs`` to adapt an existing BIDS-compliant dataset
to be BIDS-NBS compliant.
"""